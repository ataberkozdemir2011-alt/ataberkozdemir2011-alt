(function () {
	var PLAY = "https://play.google.com/store/apps/details?id=com.balaklavalideveloper.puzzleblock";
	var THEMES = { orman: 1, col: 1, kutup: 1, uzay: 1 };

	var TEXT = {
		tr: {
			meta: "Satırları doldur, blokları patlat, lige yüksel. Puzzle Block Android’de.",
			skip: "İçeriğe geç",
			menu: "Menü",
			menu_close: "Menüyü kapat",
			lang_group: "Dil",
			theme_group: "Temalar",
			nav_how: "Nasıl oynanır",
			nav_modes: "Modlar",
			nav_features: "Özellikler",
			nav_themes: "Temalar",
			nav_play: "Google Play",
			hero_kicker: "Android bulmaca",
			hero_tagline: "Satırları doldur, blokları patlat, lige yüksel.",
			play_small: "İndir",
			play_strong: "Google Play",
			how_title: "Nasıl oynanır",
			how_lead: "Parçalar yukarıdan düşer. Bir satır dolunca o satır patlar.",
			step1_t: "Kaydır",
			step1_d: "Parçayı sola veya sağa al.",
			step2_t: "Döndür",
			step2_d: "Parçayı oturacağı yöne çevir.",
			step3_t: "Hızlandır",
			step3_d: "Aşağı ile parçayı daha hızlı düşür.",
			step4_t: "Patlat",
			step4_d: "Dolu satır yok olur. Patlayan her blok 1 jeton kazandırır.",
			modes_title: "İki oyun",
			modes_lead: "İstediğin zaman sınırsız oyna ya da botla yarış.",
			mode_classic_k: "Mod",
			mode_classic_t: "Klasik",
			mode_classic_d: "Sınırsız tur. Yüksek skoru kovala. Tahta dolunca oyun biter.",
			mode_race_k: "50 seviye",
			mode_race_t: "Yarış",
			mode_race_d: "Bot hedef puana varmadan sen ulaş. Tahta dolarsa seviye kaybedilir. Kazanınca lig puanı gelir.",
			feat_title: "Her gün bir sebep",
			feat_lead: "Görevler, ödüller ve haftalık lig aynı jetonla döner.",
			feat_quests_t: "Görevler",
			feat_quests_d: "Günlük ve haftalık işler: skor, jeton, yarış seviyesi ve oynama süresi.",
			feat_daily_t: "Günlük ödül",
			feat_daily_d: "Her gün açılan jeton ödülü. Seriyi kaçırma.",
			feat_xp_t: "XP yolu",
			feat_xp_d: "Oynadıkça biriken deneyim. Kilitli ödüller sırayla açılır.",
			feat_league_t: "Haftalık lig",
			feat_league_d: "Sıralama Pazartesi 00:00’da sıfırlanır. Üst sıralar jeton kazandırır.",
			lg1: "Çaylak",
			lg2: "Orta",
			lg3: "Orta Üstü",
			lg4: "Usta",
			lg5: "Profesyonel",
			shop_title: "Mağaza güçlendirmeleri",
			shop_lead: "Jetonla alınan eşyalar o turda işe yarar.",
			item_bomb_t: "Dinamit",
			item_bomb_d: "Tahtada rastgele 4 bloğu patlatır.",
			item_2x_t: "2X",
			item_2x_d: "2 dakika boyunca puanı ikiye katlar.",
			item_rainbow_t: "Renkli blok",
			item_rainbow_d: "Patlayınca tahtadaki tüm blokları temizler.",
			item_ice_t: "Buz",
			item_ice_d: "45 saniye boyunca düşüşü yavaşlatır.",
			item_hammer_t: "Çekiç",
			item_hammer_d: "Seçtiğin yerde 2x2 alanı patlatır.",
			item_hold_t: "Tutucu",
			item_hold_d: "Düşen parçayı sıraya alır, yerine yenisi gelir.",
			item_laser_t: "Lazer",
			item_laser_d: "En alttaki dolu satırı temizler.",
			item_undo_t: "Geri Al",
			item_undo_d: "Son yerleşen parçayı yeniden düşürür.",
			themes_title: "Dört tema",
			themes_lead: "Orman, çöl, kutup veya uzay. Seçimin bu sayfanın rengini de değiştirir.",
			theme_forest: "Orman",
			theme_desert: "Çöl",
			theme_polar: "Kutup",
			theme_space: "Uzay",
			footer_by: "Geliştiren",
			footer_privacy: "Gizlilik Politikası"
		},
		en: {
			meta: "Fill the lines, clear the blocks, climb the league. Puzzle Block on Android.",
			skip: "Skip to content",
			menu: "Menu",
			menu_close: "Close menu",
			lang_group: "Language",
			theme_group: "Themes",
			nav_how: "How to play",
			nav_modes: "Modes",
			nav_features: "Features",
			nav_themes: "Themes",
			nav_play: "Google Play",
			hero_kicker: "Android puzzle",
			hero_tagline: "Fill the lines, clear the blocks, climb the league.",
			play_small: "Get it on",
			play_strong: "Google Play",
			how_title: "How to play",
			how_lead: "Pieces fall from the top. A full line clears.",
			step1_t: "Slide",
			step1_d: "Move the piece left or right.",
			step2_t: "Rotate",
			step2_d: "Turn the piece so it fits.",
			step3_t: "Drop",
			step3_d: "Press down to make the piece fall faster.",
			step4_t: "Clear",
			step4_d: "A full line disappears. Every cleared block is 1 coin.",
			modes_title: "Two ways to play",
			modes_lead: "Go endless, or race the bot.",
			mode_classic_k: "Mode",
			mode_classic_t: "Classic",
			mode_classic_d: "Endless play. Chase the high score. The round ends when the board locks.",
			mode_race_k: "50 levels",
			mode_race_t: "Race",
			mode_race_d: "Reach the goal before the bot. A locked board loses the level. A win earns league points.",
			feat_title: "A reason to come back",
			feat_lead: "Quests, rewards, and the weekly league all spend the same coins.",
			feat_quests_t: "Quests",
			feat_quests_d: "Daily and weekly jobs: score, coins, race levels, and play time.",
			feat_daily_t: "Daily reward",
			feat_daily_d: "A coin reward that opens each day. Keep the streak.",
			feat_xp_t: "XP road",
			feat_xp_d: "Experience builds as you play. Locked rewards open in order.",
			feat_league_t: "Weekly league",
			feat_league_d: "Ranks reset Monday at 00:00. Higher places pay coins.",
			lg1: "Rookie",
			lg2: "Medium",
			lg3: "Upper",
			lg4: "Master",
			lg5: "Pro",
			shop_title: "Shop boosts",
			shop_lead: "Items bought with coins work for that round.",
			item_bomb_t: "Dynamite",
			item_bomb_d: "Explodes 4 blocks at a random spot.",
			item_2x_t: "2X",
			item_2x_d: "Doubles points for 2 minutes.",
			item_rainbow_t: "Rainbow block",
			item_rainbow_d: "When it clears, every block on the board goes with it.",
			item_ice_t: "Ice",
			item_ice_d: "Slows the fall for 45 seconds.",
			item_hammer_t: "Hammer",
			item_hammer_d: "Destroys a 2x2 area you pick.",
			item_hold_t: "Hold",
			item_hold_d: "Sends the falling piece to Next and drops a new one.",
			item_laser_t: "Laser",
			item_laser_d: "Clears the lowest occupied row.",
			item_undo_t: "Undo",
			item_undo_d: "Lifts the last locked piece so you can drop it again.",
			themes_title: "Four themes",
			themes_lead: "Jungle, desert, arctic, or space. Your pick recolors this page too.",
			theme_forest: "Jungle",
			theme_desert: "Desert",
			theme_polar: "Arctic",
			theme_space: "Space",
			footer_by: "Developed by",
			footer_privacy: "Privacy Policy"
		}
	};

	function lang() {
		return document.documentElement.lang === "en" ? "en" : "tr";
	}

	function applyLang(code) {
		if (!TEXT[code]) code = "tr";
		document.documentElement.lang = code;
		var pack = TEXT[code];
		document.querySelectorAll("[data-i18n]").forEach(function (el) {
			var key = el.getAttribute("data-i18n");
			if (pack[key]) el.textContent = pack[key];
		});
		document.querySelectorAll("[data-i18n-aria]").forEach(function (el) {
			var key = el.getAttribute("data-i18n-aria");
			if (pack[key]) el.setAttribute("aria-label", pack[key]);
		});
		document.querySelectorAll("[data-i18n-meta]").forEach(function (el) {
			var key = el.getAttribute("data-i18n-meta");
			if (pack[key]) el.setAttribute("content", pack[key]);
		});
		document.querySelectorAll("[data-lang]").forEach(function (btn) {
			btn.setAttribute("aria-pressed", btn.getAttribute("data-lang") === code ? "true" : "false");
		});
		var toggle = document.querySelector(".nav-toggle");
		if (toggle) {
			var open = toggle.getAttribute("aria-expanded") === "true";
			var label = open ? pack.menu_close : pack.menu;
			toggle.textContent = label;
			toggle.setAttribute("aria-label", label);
		}
		try { localStorage.setItem("pb_lang", code); } catch (e) {}
	}

	function applyTheme(id) {
		if (!THEMES[id]) id = "orman";
		document.documentElement.dataset.theme = id;
		document.querySelectorAll("[data-theme-pick]").forEach(function (btn) {
			btn.setAttribute("aria-pressed", btn.getAttribute("data-theme-pick") === id ? "true" : "false");
		});
		var meta = document.querySelector('meta[name="theme-color"]');
		if (meta) {
			var colors = { orman: "#05080a", col: "#1c1208", kutup: "#061018", uzay: "#05020e" };
			meta.setAttribute("content", colors[id]);
		}
		try { localStorage.setItem("pb_theme", id); } catch (e) {}
	}

	document.querySelectorAll('a[href="' + PLAY + '"]').forEach(function (link) {
		link.setAttribute("href", PLAY);
	});

	document.querySelectorAll("[data-lang]").forEach(function (btn) {
		btn.addEventListener("click", function () {
			applyLang(btn.getAttribute("data-lang"));
		});
	});

	document.querySelectorAll("[data-theme-pick]").forEach(function (btn) {
		btn.addEventListener("click", function () {
			applyTheme(btn.getAttribute("data-theme-pick"));
		});
	});

	var toggle = document.querySelector(".nav-toggle");
	var nav = document.getElementById("site-nav");
	if (toggle && nav) {
		toggle.addEventListener("click", function () {
			var open = toggle.getAttribute("aria-expanded") !== "true";
			toggle.setAttribute("aria-expanded", open ? "true" : "false");
			nav.classList.toggle("is-open", open);
			var label = open ? TEXT[lang()].menu_close : TEXT[lang()].menu;
			toggle.textContent = label;
			toggle.setAttribute("aria-label", label);
		});
		nav.querySelectorAll("a").forEach(function (link) {
			link.addEventListener("click", function () {
				toggle.setAttribute("aria-expanded", "false");
				nav.classList.remove("is-open");
				toggle.textContent = TEXT[lang()].menu;
				toggle.setAttribute("aria-label", TEXT[lang()].menu);
			});
		});
	}

	applyLang(lang());
	applyTheme(document.documentElement.dataset.theme || "orman");
})();
